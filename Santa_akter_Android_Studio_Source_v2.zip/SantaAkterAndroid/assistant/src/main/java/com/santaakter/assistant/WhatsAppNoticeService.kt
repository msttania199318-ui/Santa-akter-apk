package com.santaakter.assistant

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class WhatsAppNoticeService : AccessibilityService() {
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == "com.whatsapp" || pkg == "com.whatsapp.w4b") {
            Toast.makeText(this, "Santa akter: ডিভাইস লিংক করার আগে নম্বর ও ডিভাইস যাচাই করুন।", Toast.LENGTH_SHORT).show()
        }
    }
    override fun onInterrupt() = Unit
}
