# Santa akter — Android Studio source

Two separate Android applications:
- Santa akter Assistant (`com.santaakter.assistant`)
- Santa akter Controller (`com.santaakter.controller`)

## Included
- Opens WhatsApp Web in the browser.
- Bengali voice guidance using Android TextToSpeech.
- Opens Android Accessibility settings.
- Controller can launch Assistant and WhatsApp Web.
- Assistant's optional AccessibilityService only notices when WhatsApp enters the foreground and displays a reminder.

## Pairing and safety
The user must personally review and enter any WhatsApp pairing code on their own phone and approve the linked device. The apps do not read, copy, transmit, auto-fill, or auto-submit pairing codes; they do not click WhatsApp's link/approve controls; they do not bypass Android auto-launch or background restrictions. Never share a pairing code with anyone.

## Build APKs
1. Install Android Studio and Android SDK Platform 35.
2. Open this folder in Android Studio and sync Gradle.
3. Use Build > Build Bundle(s) / APK(s) > Build APK(s) for each module.
4. Find outputs in `assistant/build/outputs/apk/debug/` and `controller/build/outputs/apk/debug/`.

APK binaries are not compiled in this environment because Android SDK/Gradle build tools are unavailable.
