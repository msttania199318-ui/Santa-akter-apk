package com.santaakter.controller

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(26, 32, 26, 32)
            setBackgroundColor(Color.rgb(248, 248, 246))
        }
        val title = TextView(this).apply {
            text = "Santa akter\nController"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(30, 30, 30))
        }
        val info = TextView(this).apply {
            text = "Assistant অ্যাপটি একই ফোনে ইনস্টল করুন। Controller থেকে Assistant, WhatsApp Web এবং Android Accessibility সেটিংস খোলা যাবে।"
            textSize = 16f
            gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
            setPadding(0, 24, 0, 28)
        }
        val openAssistant = Button(this).apply {
            text = "Assistant খুলুন"
            setOnClickListener {
                val launch = packageManager.getLaunchIntentForPackage("com.santaakter.assistant")
                if (launch != null) startActivity(launch)
                else info.text = "Santa akter Assistant ইনস্টল করা নেই। আগে Assistant ইনস্টল করুন।"
            }
        }
        val web = Button(this).apply {
            text = "WhatsApp Web খুলুন"
            setOnClickListener { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://web.whatsapp.com/"))) }
        }
        val settings = Button(this).apply {
            text = "Accessibility সেটিংস"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        root.addView(title); root.addView(info); root.addView(openAssistant); root.addView(web); root.addView(settings)
        setContentView(root)
    }
}
