package com.santaakter.assistant

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.speech.tts.TextToSpeech
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.view.Gravity
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private val guide = "WhatsApp Web খুলুন। ওয়েবসাইটে আপনার নম্বর দিয়ে পেয়ারিং কোড চাইলে সেটি দেখুন। এরপর নিজের ফোনে WhatsApp খুলে Linked devices, Link a device নির্বাচন করুন। ওয়েবে দেখানো কোডটি ফোনে নিজে হাতে লিখুন এবং ফোনে পরিচিতি ও ডিভাইস যাচাই করে অনুমোদন দিন। কাউকে কোড দেবেন না।"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(26, 32, 26, 32)
            setBackgroundColor(Color.rgb(248, 248, 246))
        }
        val title = TextView(this).apply {
            text = "Santa akter"
            textSize = 30f
            setTextColor(Color.rgb(30, 30, 30))
            gravity = Gravity.CENTER
        }
        val subtitle = TextView(this).apply {
            text = "WhatsApp Assistant\n\nনিরাপদ Link Device সহায়তা\nকোড নিজে দেখে নিজের ফোনে লিখুন। এই অ্যাপ কোড পড়ে, কপি করে বা স্বয়ংক্রিয়ভাবে লগইন সম্পন্ন করে না।"
            textSize = 16f
            setTextColor(Color.DKGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 22, 0, 24)
        }
        val web = Button(this).apply {
            text = "WhatsApp Web খুলুন"
            setOnClickListener {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://web.whatsapp.com/")))
            }
        }
        val voice = Button(this).apply {
            text = "ভয়েস নির্দেশনা শুনুন"
            setOnClickListener {
                if (tts != null) tts?.speak(guide, TextToSpeech.QUEUE_FLUSH, null, "santa-guide")
            }
        }
        val setup = Button(this).apply {
            text = "Accessibility সেটিংস খুলুন"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        val reminder = Button(this).apply {
            text = "WhatsApp খুলুন"
            setOnClickListener {
                val launch = packageManager.getLaunchIntentForPackage("com.whatsapp")
                if (launch != null) startActivity(launch)
            }
        }
        root.addView(title); root.addView(subtitle); root.addView(web)
        root.addView(voice); root.addView(setup); root.addView(reminder)
        setContentView(root)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) tts?.language = Locale("bn", "BD")
    }

    override fun onDestroy() {
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}
